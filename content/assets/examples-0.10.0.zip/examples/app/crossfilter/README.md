
This example shows how to create a crossfiter applet in Bokeh, which can
be viewed directly on a bokeh-server.

Running
=======

To view this applet directly from a bokeh server, you simply need to
run a bokeh-server and point it at the stock example script:

    bokeh-server --script crossfilter_app.py

Now navigate to the following URL in a browser:

    http://localhost:5006/bokeh/crossfilter
