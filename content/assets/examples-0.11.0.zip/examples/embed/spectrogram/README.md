The spectrogram example requires the pyaudio library, which is
available via conda (python 2.7 only):

    conda install -c bokeh pyaudio

Or to build pyaudio from source, see the documentation
here:

    https://people.csail.mit.edu/hubert/pyaudio/

To run the spectrogram example:

    python spectogram.py

Then open your webbrowser at: http://localhost:5000